ARISE PLAYER — ANDROID PROJECT

This ZIP contains the Android app source project and a GitHub Actions workflow to build a debug APK in the cloud.

IMPORTANT
- This is source code, not a prebuilt APK.
- This environment does not have the Android SDK / Gradle installed, so it cannot compile the APK directly here.
- The APK is unsigned for Play Store release, but a debug APK can be installed on your own Android phone.

PHONE-ONLY BUILD PATH (GitHub)
1. Extract this ZIP.
2. Create a GitHub repository and upload all extracted files to the repository's main branch.
3. Open the repository's Actions tab.
4. Choose "Build ARISE APK", then tap "Run workflow" (or wait for the push build to finish).
5. Open the completed workflow run and download the "ARISE-Player-APK" artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk.
7. Transfer/open app-debug.apk on Android and allow installing apps from that source if Android asks.

EASIER ALTERNATIVE
If you can use a computer with Android Studio: open this folder as a project and build the app using Build > Build APK(s).

The app stores progress locally in the app's WebView storage. Uninstalling the app or clearing its storage may erase progress.
